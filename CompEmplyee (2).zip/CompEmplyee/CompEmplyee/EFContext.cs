﻿using Microsoft.EntityFrameworkCore;

namespace CompEmplyee
{
    public class EFContext : DbContext
    {
        public EFContext(DbContextOptions<EFContext> options) : base(options) { }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Company> Companies { get; set; }
       
      
    }
}
