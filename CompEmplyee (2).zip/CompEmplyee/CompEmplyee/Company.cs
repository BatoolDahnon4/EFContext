﻿using System.ComponentModel.DataAnnotations;

namespace CompEmplyee
{
    public class Company
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; } = String.Empty;
        public string Location { get; set; } = String.Empty;
        public ICollection<Employee>? Employee { get; set; }

    }
}
