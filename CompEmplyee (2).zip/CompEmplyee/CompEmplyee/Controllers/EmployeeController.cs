﻿using CompEmplyee.interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CompEmplyee.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {

        private readonly EFContext _context;

        public EmployeeController(EFContext dbContext)
        {
            _context = dbContext;

        }

        [HttpGet]
        [Route("getEmployees")]
        public async Task<ActionResult<Employee>> GetEmployee()
        {
            var emps = await _context.Employees.Include(c => c.Company).ToListAsync();
            return Ok(emps);
        }

        [HttpGet]
        [Route("UpdateEmpCompany")]
        public async Task<ActionResult<Employee>> UpdateEmpCompany(int Id, int CompanyId)
        {
            var emp = await _context.Employees.Where(c => c.Id==Id).FirstOrDefaultAsync();
            emp.CompanyId = CompanyId;
            _context.SaveChangesAsync();
            return Ok(emp);
        }

        [HttpGet]
        [Route("getStudentById")]
        public async Task<ActionResult<Employee>> GetEmployee(int Id)
        {
            var employee = await _context.Employees.Include(c => c.Company).Where(e => e.Id == Id).FirstOrDefaultAsync();
            if (employee == null)
                return BadRequest("not found");
            return Ok(employee);
        }

        [HttpPost]
        [Route("addEmployee")]
        public async Task<ActionResult<Employee>>AddEmployee(Employee employee)
        {
            await _context.Employees.AddAsync(employee);
            _context.SaveChanges();
            return Ok("");
        }

        [HttpPut]
        [Route("updateEmployee")]
        public async Task<ActionResult<Employee>> UpdateEmployee(Employee request)
        {
          //  var emp = await _context.Employees(c => c.Company).Include.Where(i => i.id == request.id).FirstOrDefault();
        //    emp.name = employee.name;
        //    emp.age = employee.age;
        //    employees.Add(employee);

            return Ok();
        }

   
        [HttpDelete]
        [Route("deleteEmployee")]
        public async Task<ActionResult<Employee>> DeleteEmployee(int Id)
            {
            var employee = await _context.Employees.Include(c => c.Company).Where(e => e.Id == Id).FirstOrDefaultAsync();
            _context.Remove<Employee>(employee);

            return Ok(employee);
        }

    }
   
}
